import requests
import json
import os
import zipfile
import shutil

# 你的 version.json 的 Raw 链接（替换成你自己的仓库地址）
VERSION_URL = "https://github.com/9fav/times-plus/blob/main/version.josn"

# 临时下载目录
DOWNLOAD_DIR = "update_tmp"

def check_update(current_version: str):
    """
    检查远程版本号是否比当前版本高，如果有更新则下载并解压更新包。
    :param current_version: 本地软件版本号（例如 "1.0.0"）
    """
    try:
        print("正在检查更新...")
        response = requests.get(VERSION_URL, timeout=5)
        response.raise_for_status()
        data = response.json()

        latest_version = data.get("version")
        download_url = data.get("url")
        changelog = data.get("changelog", "无更新说明")

        if latest_version and latest_version != current_version:
            print(f"发现新版本 {latest_version}，当前版本 {current_version}")
            print(f"更新说明：{changelog}")
            if download_url:
                download_update(download_url)
            else:
                print("未找到下载链接。")
        else:
            print("当前已是最新版本。")

    except Exception as e:
        print("检查更新失败：", e)


def download_update(url: str):
    """
    下载更新包并解压覆盖旧版本。
    :param url: 更新包下载地址
    """
    try:
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        file_path = os.path.join(DOWNLOAD_DIR, "update.zip")

        print("正在下载更新包...")
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(file_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

        print("下载完成，正在解压更新包...")
        with zipfile.ZipFile(file_path, "r") as zip_ref:
            zip_ref.extractall(DOWNLOAD_DIR)

        # 将解压后的文件覆盖到当前目录
        for item in os.listdir(DOWNLOAD_DIR):
            src_path = os.path.join(DOWNLOAD_DIR, item)
            dst_path = os.path.join(".", item)

            if os.path.isdir(src_path):
                if os.path.exists(dst_path):
                    shutil.rmtree(dst_path)
                shutil.move(src_path, dst_path)
            else:
                shutil.move(src_path, dst_path)

        print("更新完成，请重启程序。")

    except Exception as e:
        print("下载更新失败：", e)
